import React from "react";
import restaurants from "./restaurants";
import "./App.css";

const App = () => {
  return (
    <div>
      <h1>List of Restaurants</h1>
      <div className="restaurants">
        {restaurants.businesses.map((r, key) => {
          return (
            <div key={key} className="cards">
              <img src={r.image_url} />
              <p className="restaurant">{r.name}</p>
              <p>
                {r.rating} Stars, {r.review_count} Reviews
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default App;
